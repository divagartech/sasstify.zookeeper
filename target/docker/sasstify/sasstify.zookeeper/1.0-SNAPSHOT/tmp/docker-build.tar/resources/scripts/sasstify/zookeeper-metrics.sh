#!/usr/bin/env bash

curl -sb -H "Accept: application/json" "http://localhost:8080/commands/monitor"